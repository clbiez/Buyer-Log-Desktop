from pathlib import Path
import json,hashlib,subprocess,tarfile
repo=Path('/workspace/phase7-shared-evidence');ev=Path('/workspace/phase7-packaging-evidence');art=repo/'docs/performance-program/phase-7-artifacts'
heads=json.loads((ev/'heads.json').read_text());checks=json.loads((ev/'github-checks-initial.json').read_text());results=json.loads((ev/'validation-results.json').read_text());proof=json.loads((ev/'review-and-ownership-proof.json').read_text());contract=json.loads((repo/'docs/performance-program/phase-7-packaging-contract.json').read_text())
assert set(results)=={'snapshot','images','parser'}
assert all(r['status']=='passed' and r['npmTest']['exitCode']==0 and r['npmTest']['fail']==0 and r['npmTest']['cancelled']==0 for r in results.values())
for name,r in results.items():
 assert r['head']==heads['production'][name]['head']
 assert all(x['exitCode']==0 for x in r['checks'])
 for c in r['checks']:assert hashlib.sha256((ev/c['log']).read_bytes()).hexdigest()==c['logSha256']
 assert hashlib.sha256((ev/r['npmTest']['log']).read_bytes()).hexdigest()==r['npmTest']['logSha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/phase7-'+name,text=True).strip()==r['head']
manifest=json.loads((art/'manifest.json').read_text())
for file,sha in proof['unchangedExistingEvidence'].items():assert hashlib.sha256((repo/file).read_bytes()).hexdigest()==sha
bundle=art/'final-branch-validation.tar.gz'
with tarfile.open(bundle,'w:gz') as tar:
 for file in sorted(ev.rglob('*')):
  if file.is_file():tar.add(file,arcname=str(file.relative_to(ev)))
final={'commonPr':913,'commonBranch':'perf/phase7-shared-evidence','frozenCommonParent':heads['frozenCommonHead'],'production':{},'historicalCombinedTreeFullNpmTest':manifest['combinedTreeFullNpmTest'],'reviewAndOwnership':proof,'validationArchive':{'file':bundle.name,'sha256':hashlib.sha256(bundle.read_bytes()).hexdigest()},'productionUnchanged':True,'performanceMeasurementsRepeated':False,'newGeneralIndependentReview':False,'mergeMain':False,'testPublication':False,'stablePublication':False}
bypr={x['pr']:x for x in checks}
for name,r in results.items():
 x={**r,'github':bypr[r['pr']]['ci'],'base':'perf/phase7-shared-evidence','originalReviewHead':contract['production'][name]['originalReviewHead'],'reviewedProductionCommit':contract['production'][name]['reviewedProductionCommit'],'productionFilesByteIdentical':True,'oldHeadIsAncestor':True,'finalAcceptance':'pending'}
 for run in x['github']['workflow_runs']:assert run['status']=='completed' and run['conclusion']=='success'
 final['production'][name]=x
(art/'final-branch-validation.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
manifest['finalBranchRegression']={'results':'final-branch-validation.json','archive':'final-branch-validation.tar.gz','archiveSha256':final['validationArchive']['sha256'],'scope':'Each final production PR head individually; historical combined-tree result remains separate'}
(art/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
rows=[];reviewrows=[]
for name in ['snapshot','images','parser']:
 r=final['production'][name];n=r['npmTest'];run=r['github']['workflow_runs'][0];runurl='https://github.com/clbiez/Buyer-Log-Desktop/actions/runs/'+str(run['id'])
 rows.append(f"| [#{r['pr']}](https://github.com/clbiez/Buyer-Log-Desktop/pull/{r['pr']}) | `{r['head']}` | {n['files']} | {n['pass']} | {n['fail']} / {n['cancelled']} / {n['skipped']} | [SUCCESS]({runurl}) |")
 reviewrows.append(f"| #{r['pr']} | `{r['reviewedProductionCommit']}` | `{r['originalReviewHead']}` | `{r['head']}` | aynı blob + diff SHA / identical |")
report='''# Faz 7 · Paketleme ve devir / Packaging and handoff

**Kapsam sabit:** yalnız paketleme ve doğrulama. Üretim/test dosyası değişikliği, yeni optimizasyon, performans koşusu veya yeni genel bağımsız review yok. / Packaging and validation only; no production/test edits, optimization, performance rerun or general review round.

## PR sahipliği / Ownership

- [#913](https://github.com/clbiez/Buyer-Log-Desktop/pull/913): eski ortak 12 doküman/artefakt/benchmark dosyasının tek sahibi; ayrıca ortak paketleme/devir kaydı ve bağımlı PR'lar için CI hedef filtresi.
- #909/#910/#911'in hedefi `perf/phase7-shared-evidence`. Ortak dala göre sırasıyla **6 / 5 / 4** dosya; yalnız kendi üretim/test deltaları. Dört PR'ın changed-files kümeleri ikili olarak ayrık.
- Ortak dal üretim dallarına normal merge ile alındı; rebase/force-push yok. Aşağıdaki eski review head'lerinin tamamı nihai üretim head'lerinin ancestor'ı. Üretim dallarının sabit ortak parent'i `FROZEN_COMMON`.
- Sonraki ortak kapanış commit'i yalnız doküman/log kanıtı taşır. Üretim head'lerini tekrar değiştirmez. / Closing evidence advances only the common documentation branch; production heads stay fixed.

## Her nihai dalın tam regresyonu / Full regression per final production head

Her dalda kendi `resources/app` dizininde, kendi ortak preload dosyası ile **ayrı ve sırayla** `npm test` çalıştı. Tablodaki üç sonuç birleşik ağaçtan türetilmedi. / Three separate full runs on the exact heads below, not inferred from the combined run.

| PR | Nihai üretim SHA / Final production SHA | Dosya / Files | PASS | fail / cancel / skip | Gerçek GitHub checks |
| --- | --- | ---: | ---: | ---: | --- |
'''+'\n'.join(rows)+'''

Her dalda i18n, mevcut release-note validation, dependency inventory ve diff kontrolleri exit 0. 65 platform/opt-in skip her dalda ayrı raporlanır; Windows veya soak doğrulaması yapılmış sayılmaz. GitHub fast checks gerçek son head'lere aittir; yerel tam regresyonun yerine sunulmaz.

Tarihsel **birleşik ağaç**: 1.294 dosya / 8.872 PASS / 0 fail / 0 cancel / 65 skip, üretim kaynak commit'i `ee18c4c595e1764c19ad3a31bd9aba892d5b4fe6`. Eski tam log ve SHA'ları korunur; bu sonuç bağımsız dal regresyonu diye sunulmaz.

İlk #909 tam denemesi, worktree dependency symlink'lerinin installer fixture ZIP'ine alınmaması nedeniyle iki testte durdu (`INSTALLER_DEPENDENCIES_MISSING: resedit`). Bu koşu arşivde `attempt-1-linked-deps/` altında durur. Yalnız ignored node_modules dizinleri mevcut bağımlılıkların gerçek kopyalarıyla hazırlandı; installer/test/üretim kodu ve kilit dosyaları değiştirilmedi. Aynı installer paketi 4/4 geçti; ardından yukarıdaki üç tam çevrim alındı. / The retained failed attempt was dependency setup, fixed with actual local dependency files, without changing assertions or production.

## Mevcut bağımsız incelemenin taşınması / Existing review correspondence

| PR | İncelenen üretim kaynak commit'i | Eski review head | Nihai PR head | Kontrol |
| --- | --- | --- | --- | --- |
'''+'\n'.join(reviewrows)+'''

İncelenmiş **9 üretim dosyası**, ayrıca **6 test/helper** dosyası Git blob ve sha256 ile birebir aynı. Her üretim kapsamının eski review kaynağına göre diff SHA256'sı yeni ortak-base diff SHA256'sıyla aynı. Dosya bazında eşleştirme ve ancestor sonucu [JSON kanıtında](phase-7-artifacts/final-branch-validation.json). Yeni genel ikinci model turu başlatılmadı.

Kapasite P1'inin önceki RED → GREEN ve gpt-6-astra **11/11** kapanış kanıtı korunur. Eski tanı arşivi SHA256 `6a42c9b638e6e12a23579da880283d196e5e17c20235e659c1885785837e5d59`; performans JSON'u, PNG'ler ve benchmark/probe/preload dosyalarının orijinal hash'leri değişmedi. / Original review closure and measurements remain intact; this is a correspondence check, not a new review.

## Kabul ve açık kalan işler / Acceptance and remaining work

- **DS-08, INT-04/05, INT-11:** uygulandı; **son kabul bekliyor** / implemented; final acceptance pending.
- **DS-11 ve INT-07:** gerekli ortam ölçülemedi; **açık** / required environment measurement unavailable; open.
- **INT-10:** upstream kapasitesi/kazanç doğrulanmadı; **açık** / upstream capacity/gain unverified; open.
- **ADMIN-02:** güvenli kazanç gösteren aday yok; **kontrol koşuları hızlanma kanıtı değil** / no candidate showing safe gain; controls are not speedup evidence.

DS-08 tarihsel toplam süre **374.920 → 404.012 ms (+%7,76)**, süreç tepe RSS **273.508 → 289.195 MiB**. Fallback eski MAIN stall'ını koruyabilir. Son kabul verilmiş sayılmaz. Gerçek SMB/PLM veya Windows kabulü iddia edilmez.

## Sonraki adım / Next step

P1 PR'ları merge öncesinde durur; #913 de taslaktır. Sonraki sohbet kullanıcı kabulünden sonra önce ortak #913'ü ele alır; üretim PR'larının hedefi daha sonra main'e çevrilebilir. Bu taşıma için rebase/force-push gerekmez. Bu SHA'lardan sonra üretim/test/runtime tabanı değişirse gerekli doğrulamalar yeni ağaç için yeniden değerlendirilir; eski test sonucu yeni kod sonucu değildir.

**Merge yapılmadı. TEST yayımlanmadı. STABLE yayımlanmadı.** `public/**` aynı. / No merge or TEST/STABLE publication; client files unchanged.

[Makinece okunur sonuç ve dosya eşleştirmesi](phase-7-artifacts/final-branch-validation.json) · [Tam loglar ve saklanan başarısız kurulum denemesi](phase-7-artifacts/final-branch-validation.tar.gz) · [Ölçüm raporu](phase-7-server-report.md).
'''
report=report.replace('FROZEN_COMMON',heads['frozenCommonHead'])
(repo/'docs/performance-program/phase-7-packaging-handoff.md').write_text(report)
p=repo/'docs/performance-program/phase-7-server-report.md';s=p.read_text();s=s.replace('Güvenli snapshot/son doğrulamayı çıkarmadan I/O kazancı gösteren alternatif yok;','Bu görevde güvenli kazanç gösteren bir aday sunulmadı; kontrol koşuları hızlanma kanıtı değildir;');p.write_text(s)
print(json.dumps({k:{'head':v['head'],'files':v['npmTest']['files'],'pass':v['npmTest']['pass'],'skip':v['npmTest']['skipped']} for k,v in final['production'].items()},ensure_ascii=False))
