from pathlib import Path
import subprocess,os,json,re,time,hashlib
root=Path('/workspace/phase7-packaging-evidence');heads=json.loads((root/'heads.json').read_text());results={}
def save():
 target=root/'validation-results.json';temporary=target.with_suffix('.tmp');temporary.write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');temporary.replace(target)
for name,spec in heads['production'].items():
 app=Path('/workspace/phase7-'+name+'/resources/app')
 def git(*args):return subprocess.check_output(['git',*args],cwd=app,text=True).strip()
 assert git('rev-parse','HEAD')==spec['head']
 assert not git('status','--porcelain')
 env={**os.environ,'NODE_OPTIONS':f'--require {app}/scripts/phase7-test-env.cjs'}
 record={'head':spec['head'],'pr':spec['pr'],'status':'running','startedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'checks':[]};results[name]=record;save()
 print(f'START {name} {spec["head"]}',flush=True)
 log=root/f'{name}-npm-test.log';start=time.monotonic()
 with log.open('w') as output:run=subprocess.run(['npm','test'],cwd=app,env=env,stdout=output,stderr=subprocess.STDOUT)
 text=log.read_text();record['npmTest']={'exitCode':run.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),**{k:sum(map(int,re.findall(r'^ℹ '+k+r' (\d+)$',text,re.M))) for k in ['tests','pass','fail','cancelled','skipped','todo']}}
 match=re.search(r'PASS — (\d+) test dosyası',text);record['npmTest']['files']=int(match.group(1)) if match else None
 record['status']='failed' if run.returncode else 'checking';save()
 print(f'NPM {name} '+json.dumps(record['npmTest']),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
 for label,args in [('i18n',['npm','run','i18n:check']),('release-notes',['npm','run','release:notes:validate']),('inventory',['node','scripts/dependency-inventory.js','--check']),('diff',['git','diff','--check',heads['frozenCommonHead']+'...HEAD'])]:
  log=root/f'{name}-{label}.log'
  with log.open('w') as output:check=subprocess.run(args,cwd=app,env=env,stdout=output,stderr=subprocess.STDOUT)
  record['checks'].append({'name':label,'exitCode':check.returncode,'log':log.name,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()});save()
  if check.returncode:record['status']='failed';save();raise SystemExit(check.returncode)
 assert git('rev-parse','HEAD')==spec['head']
 assert not git('status','--porcelain')
 record['status']='passed';record['finishedUtc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save();print('PASS '+name,flush=True)
