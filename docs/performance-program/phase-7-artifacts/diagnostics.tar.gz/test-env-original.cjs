'use strict';
if(process.argv.some(arg=>arg.endsWith('.test.js'))){
 const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'bl-phase7-suite-'));
 for(const name of ['SERVER_DATA','DATA','LOCAL_DATA','TEMP'])process.env[`BUYER_LOG_${name}_ROOT`]=path.join(root,name);
 process.env.BUYER_LOG_CONFIG_PATH=path.join(root,'config.json');
 process.on('exit',()=>fs.rmSync(root,{recursive:true,force:true}));
}
