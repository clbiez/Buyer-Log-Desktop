'use strict';
const fs=require('node:fs'),wt=require('node:worker_threads'),Real=wt.Worker;
const events=[],emit=(event,data={})=>{const row={at:process.hrtime.bigint().toString(),pid:process.pid,event,...data};events.push(row);if(process.env.PROFILER_OBSERVE==='1')fs.writeSync(2,JSON.stringify(row)+'\n');};
if(process.env.PROFILER_OBSERVE==='1'){
 wt.Worker=class extends Real{constructor(...args){super(...args);this.on('online',()=>emit('worker-online'));this.on('message',m=>emit('worker-message',{id:m.id,ok:m.ok,running:m.running}));this.on('exit',code=>emit('worker-exit',{code}));this.on('error',e=>emit('worker-error',{code:e.code}));}postMessage(message,...args){emit('worker-send',{id:message.id,operation:message.operation});return super.postMessage(message,...args);}};
}
const {createStallProfiler}=require(process.argv[2]);
(async()=>{for(let i=0;i<4;i++){
 emit('cycle-start',{cycle:i});const p=createStallProfiler({windowMs:0,log:line=>emit('summary',{unavailable:line.includes('unavailable')})});
 if(!p||!await p.start())throw Error('profiler start failed');
 const until=performance.now()+15;while(performance.now()<until)Math.sqrt(Math.random());
 await p.rotate();await p.capture(12000);emit('stop-called',{cycle:i});await p.stop();emit('stop-resolved',{cycle:i});
}emit('completed');})().catch(e=>{fs.writeSync(2,e.stack+'\n');process.exitCode=1;});
process.on('exit',code=>emit('process-exit',{code}));
