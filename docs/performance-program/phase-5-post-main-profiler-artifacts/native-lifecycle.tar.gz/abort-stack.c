#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <unistd.h>
#include <stdlib.h>
void abort(void) {
  void *frames[64];
  const char msg[]="DIAGNOSTIC abort() native stack (observer only)\n";
  write(2,msg,sizeof(msg)-1);
  int count=backtrace(frames,64);
  backtrace_symbols_fd(frames,count,2);
  void (*real_abort)(void)=dlsym(RTLD_NEXT,"abort");
  real_abort();
  _exit(134);
}
