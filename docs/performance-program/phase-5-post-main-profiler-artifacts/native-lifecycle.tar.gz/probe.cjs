'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process');
const [label,moduleFile,countString]=process.argv.slice(2),count=Number(countString||24),out=__dirname;
let next=0;const results=[];
(async()=>{await Promise.all(Array.from({length:4},async()=>{while(next<count){const i=next++,stdout=fs.openSync(path.join(out,label+'-'+i+'.stdout.log'),'wx'),stderr=fs.openSync(path.join(out,label+'-'+i+'.stderr.log'),'wx');
 const record=await new Promise(resolve=>{const child=spawn(process.execPath,[path.join(out,'lifecycle-child.cjs'),moduleFile],{env:process.env,stdio:['ignore',stdout,stderr]});child.on('error',error=>resolve({error:error.message}));child.on('close',(code,signal)=>resolve({code,signal}));});fs.closeSync(stdout);fs.closeSync(stderr);results.push({i,...record});
}}));fs.writeFileSync(path.join(out,label+'.json'),JSON.stringify({moduleFile,count,concurrency:4,results},null,2)+'\n');console.log(JSON.stringify({label,total:count,failed:results.filter(r=>r.code!==0)}));process.exitCode=results.some(r=>r.code!==0)?1:0;})().catch(e=>{console.error(e);process.exitCode=1;});
