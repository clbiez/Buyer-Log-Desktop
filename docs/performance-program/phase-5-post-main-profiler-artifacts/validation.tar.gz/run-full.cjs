'use strict';
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const out=__dirname,tmp=fs.mkdtempSync('/tmp/buyerlog-profiler-final-'),runner=path.join(tmp,'runner');fs.mkdirSync(runner);
const env={...process.env,TMPDIR:tmp,BUYER_LOG_DATA_ROOT:path.join(runner,'app'),BUYER_LOG_LOCAL_DATA_ROOT:path.join(runner,'local'),BUYER_LOG_SERVER_DATA_ROOT:path.join(runner,'server'),BUYER_LOG_CONFIG_PATH:path.join(runner,'config.json'),BUYER_LOG_CENTRAL_IAM_ENABLED:'0'};
for(const k of ['BUYER_LOG_TEMP_ROOT','BUYER_LOG_AUTH_DATA_ROOT','BUYER_LOG_AUTH_ROOT','NODE_OPTIONS','LD_PRELOAD','PROFILER_OBSERVE'])delete env[k];
for(const k of ['BUYER_LOG_DATA_ROOT','BUYER_LOG_LOCAL_DATA_ROOT','BUYER_LOG_SERVER_DATA_ROOT'])fs.mkdirSync(env[k],{recursive:true});
const meta={synthetic:true,codeSha:spawnSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).stdout.trim(),cwd:process.cwd(),command:['npm','test'],node:process.version,env:Object.fromEntries(Object.entries(env).filter(([k])=>k==='TMPDIR'||k.startsWith('BUYER_LOG_'))),startedAt:new Date().toISOString()};
fs.writeFileSync(path.join(out,'full-main.json'),JSON.stringify(meta,null,2)+'\n');
const stdout=fs.openSync(path.join(out,'full-main.stdout.log'),'wx'),stderr=fs.openSync(path.join(out,'full-main.stderr.log'),'wx');let r;
try{r=spawnSync('npm',['test'],{cwd:process.cwd(),env,stdio:['ignore',stdout,stderr]});}finally{fs.closeSync(stdout);fs.closeSync(stderr);}
Object.assign(meta,{endedAt:new Date().toISOString(),exitCode:r.status,signal:r.signal,error:r.error?.message});fs.writeFileSync(path.join(out,'full-main.json'),JSON.stringify(meta,null,2)+'\n');
console.log(JSON.stringify({exitCode:r.status,signal:r.signal,tmp}));process.exitCode=r.status||(r.signal?1:0);
