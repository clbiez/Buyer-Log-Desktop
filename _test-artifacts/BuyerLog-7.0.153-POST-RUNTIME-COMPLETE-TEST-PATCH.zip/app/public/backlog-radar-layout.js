/* Buyer Log — Backlog radar + pivot workspace layout.
 * Görsel katmandır; Backlog pivot ve teslimat analizi hesaplarını değiştirmez.
 */
(function attachBacklogRadarLayout(root){
  'use strict';
  if(!root||!root.document)return;

  const STORAGE_KEY='lcw.backlog.radar.layout.v1';
  const CHART_TYPES=['radar','bar','line'];
  const DEFAULTS={
    pivotShare:.5,
    radarFirst:false,
    pivotCollapsed:false,
    pivotRadarCollapsed:false,
    riskCollapsed:false,
    pivotChartType:'radar',
    riskChartType:'radar',
    pivotHidden:[],
    riskHidden:[],
  };
  let state={...DEFAULTS},pivotWorkspace=null,pivotPanel=null,pivotRadarCard=null,splitter=null;
  let riskScheduled=false,pivotScheduled=false;

  const lang=()=>root.document.documentElement.lang==='en'?'en':'tr';
  const L=(tr,en)=>lang()==='en'?en:tr;
  const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const store=()=>{try{return root.BLStorage||root.localStorage||null;}catch(_){return null;}};
  function load(){
    try{
      const raw=store()?.getItem(STORAGE_KEY),saved=raw?JSON.parse(raw):{};
      state={...DEFAULTS,...saved};
      state.pivotShare=Math.max(.28,Math.min(.72,Number(state.pivotShare)||.5));
      state.pivotHidden=Array.isArray(state.pivotHidden)?state.pivotHidden.map(String):[];
      state.riskHidden=Array.isArray(state.riskHidden)?state.riskHidden.map(String):[];
      state.pivotChartType=CHART_TYPES.includes(state.pivotChartType)?state.pivotChartType:'radar';
      state.riskChartType=CHART_TYPES.includes(state.riskChartType)?state.riskChartType:'radar';
    }catch(_){state={...DEFAULTS};}
  }
  function save(){try{store()?.setItem(STORAGE_KEY,JSON.stringify(state));}catch(_){}}

  function parseNumber(value){
    let text=String(value==null?'':value).trim().replace(/\s/g,'');
    if(!text)return 0;
    const comma=text.lastIndexOf(','),dot=text.lastIndexOf('.');
    if(comma>=0&&dot>=0){
      if(comma>dot)text=text.replace(/\./g,'').replace(',','.');
      else text=text.replace(/,/g,'');
    }else if(comma>=0)text=text.replace(/\./g,'').replace(',','.');
    else if(dot>=0&&/^[-+]?\d{1,3}(?:\.\d{3})+$/.test(text))text=text.replace(/\./g,'');
    const n=Number(text.replace(/[^0-9+.-]/g,''));
    return Number.isFinite(n)?n:0;
  }
  function fmt(value){return Math.round(Number(value)||0).toLocaleString(lang()==='en'?'en-GB':'tr-TR');}
  function hiddenKey(kind){return kind==='risk'?'riskHidden':'pivotHidden';}
  function chartTypeKey(kind){return kind==='risk'?'riskChartType':'pivotChartType';}
  function chartTypeSwitch(kind){
    const current=state[chartTypeKey(kind)]||'radar',labels=lang()==='en'?{radar:'Radar',bar:'Bar',line:'Line'}:{radar:'Radar',bar:'Sütun',line:'Çizgi'};
    return '<div class="backlogChartTypeSwitch" role="group" aria-label="'+esc(L('Grafik tipi','Chart type'))+'">'
      +CHART_TYPES.map(type=>'<button type="button" data-bl-chart-type="'+type+'" data-chart-kind="'+kind+'" class="'+(current===type?'is-active':'')+'" aria-pressed="'+(current===type?'true':'false')+'">'+esc(labels[type])+'</button>').join('')
      +'</div>';
  }
  function syncChartTypeSwitch(card,kind){
    const current=state[chartTypeKey(kind)]||'radar';
    card?.querySelectorAll('[data-bl-chart-type][data-chart-kind="'+kind+'"]').forEach(button=>{
      const active=button.dataset.blChartType===current;button.classList.toggle('is-active',active);button.setAttribute('aria-pressed',String(active));
    });
  }
  function visibleItems(kind,items){
    const hidden=new Set(state[hiddenKey(kind)]||[]);
    return (items||[]).filter(item=>!hidden.has(String(item&&item.label||'')));
  }
  function radarFilterHtml(kind,items){
    const hidden=new Set(state[hiddenKey(kind)]||[]),labels=[...new Set((items||[]).map(item=>String(item&&item.label||'').trim()).filter(Boolean))];
    return '<div class="backlogRadarFilterHead"><strong>'+esc(L('Radar filtresi','Radar filter'))+'</strong><button type="button" class="tbtn" data-bl-layout="'+kind+'-filter-clear">'+esc(L('Temizle','Clear'))+'</button></div>'
      +'<div class="backlogRadarFilterList">'+labels.map(label=>'<label><input type="checkbox" data-radar-filter-kind="'+kind+'" data-radar-filter-value="'+esc(label)+'"'+(hidden.has(label)?'':' checked')+'><span>'+esc(label)+'</span></label>').join('')+'</div>';
  }
  function syncRadarFilter(card,kind,items){
    const panel=card?.querySelector('[data-radar-filter-panel="'+kind+'"]');if(!panel)return;
    const signature=JSON.stringify({items:(items||[]).map(item=>item.label),hidden:state[hiddenKey(kind)]||[]});
    if(panel.dataset.signature===signature)return;
    panel.dataset.signature=signature;panel.innerHTML=radarFilterHtml(kind,items);
  }

  function radarSvg(items,label){
    const list=(items||[]).filter(item=>item&&String(item.label||'').trim()).slice(0,10);
    if(list.length<3)return '<div class="blRadarEmpty">'+esc(L('Radar için en az 3 başlık gerekiyor.','At least 3 categories are required for the radar.'))+'</div>';
    const width=620,height=390,cx=310,cy=190,radius=108,rings=4,max=Math.max(1,...list.map(item=>Number(item.value)||0));
    const point=(index,ratio=1)=>{
      const angle=-Math.PI/2+Math.PI*2*index/list.length;
      return [cx+Math.cos(angle)*radius*ratio,cy+Math.sin(angle)*radius*ratio,angle];
    };
    let svg='<svg class="blRadarSvg" viewBox="0 0 '+width+' '+height+'" role="img" aria-label="'+esc(label)+'">';
    for(let ring=1;ring<=rings;ring++){
      const pts=list.map((_,i)=>{const p=point(i,ring/rings);return p[0].toFixed(1)+','+p[1].toFixed(1);}).join(' ');
      svg+='<polygon class="blRadarGrid" points="'+pts+'"/>';
    }
    list.forEach((_,i)=>{const p=point(i);svg+='<line class="blRadarAxis" x1="'+cx+'" y1="'+cy+'" x2="'+p[0].toFixed(1)+'" y2="'+p[1].toFixed(1)+'"/>';});
    const dataPts=list.map((item,i)=>{const p=point(i,Math.max(.035,(Number(item.value)||0)/max));return p[0].toFixed(1)+','+p[1].toFixed(1);}).join(' ');
    svg+='<polygon class="blRadarArea" points="'+dataPts+'"/>';
    list.forEach((item,i)=>{
      const p=point(i,Math.max(.035,(Number(item.value)||0)/max));
      svg+='<circle class="blRadarPoint" cx="'+p[0].toFixed(1)+'" cy="'+p[1].toFixed(1)+'" r="3.2"/>';
      const lp=point(i,1.55),anchor=Math.cos(lp[2])>.25?'start':Math.cos(lp[2])<-.25?'end':'middle';
      const labelText=String(item.label||'').length>22?String(item.label).slice(0,21)+'…':String(item.label||'');
      svg+='<text class="blRadarLabel" x="'+lp[0].toFixed(1)+'" y="'+lp[1].toFixed(1)+'" text-anchor="'+anchor+'"><tspan x="'+lp[0].toFixed(1)+'">'+esc(labelText)+'</tspan><tspan class="blRadarValue" x="'+lp[0].toFixed(1)+'" dy="12">'+esc(fmt(item.value))+'</tspan></text>';
    });
    svg+='</svg>';
    return svg;
  }

  function cartesianSvg(items,label,type){
    const list=(items||[]).filter(item=>item&&String(item.label||'').trim()).slice(0,10);
    if(!list.length)return '<div class="blRadarEmpty">'+esc(L('Grafik için veri yok.','No data for the chart.'))+'</div>';
    const width=620,height=390,left=54,right=18,top=22,bottom=92,plotW=width-left-right,plotH=height-top-bottom,max=Math.max(1,...list.map(item=>Number(item.value)||0));
    const x=index=>left+((index+.5)*plotW/list.length),y=value=>top+plotH-(Math.max(0,Number(value)||0)/max)*plotH;
    let svg='<svg class="blRadarSvg blCartesianSvg" viewBox="0 0 '+width+' '+height+'" role="img" aria-label="'+esc(label)+'">';
    for(let tick=0;tick<=4;tick++){
      const ratio=tick/4,yy=top+plotH-(ratio*plotH),value=max*ratio;
      svg+='<line class="blChartGrid" x1="'+left+'" y1="'+yy.toFixed(1)+'" x2="'+(width-right)+'" y2="'+yy.toFixed(1)+'"/>';
      svg+='<text class="blChartYLabel" x="'+(left-8)+'" y="'+(yy+3).toFixed(1)+'" text-anchor="end">'+esc(fmt(value))+'</text>';
    }
    list.forEach((item,index)=>{
      const xx=x(index),labelText=String(item.label||'').length>18?String(item.label).slice(0,17)+'…':String(item.label||'');
      svg+='<text class="blChartXLabel" x="'+xx.toFixed(1)+'" y="'+(height-bottom+22)+'" text-anchor="end" transform="rotate(-28 '+xx.toFixed(1)+' '+(height-bottom+22)+')"><title>'+esc(item.label)+'</title>'+esc(labelText)+'</text>';
    });
    if(type==='bar'){
      const groupW=plotW/list.length,barW=Math.max(8,Math.min(34,groupW*.54));
      list.forEach((item,index)=>{
        const raw=Number(item.value)||0,yy=y(raw),h=Math.max(0,top+plotH-yy),xx=x(index)-barW/2;
        svg+='<rect class="blChartBar" x="'+xx.toFixed(1)+'" y="'+yy.toFixed(1)+'" width="'+barW.toFixed(1)+'" height="'+h.toFixed(1)+'"><title>'+esc(item.label+': '+fmt(raw))+'</title></rect>';
      });
    }else{
      const pts=list.map((item,index)=>x(index).toFixed(1)+','+y(item.value).toFixed(1)).join(' ');
      if(list.length>1)svg+='<polyline class="blChartLine" points="'+pts+'"/>';
      list.forEach((item,index)=>{
        const raw=Number(item.value)||0;
        svg+='<circle class="blChartPoint" cx="'+x(index).toFixed(1)+'" cy="'+y(raw).toFixed(1)+'" r="4"><title>'+esc(item.label+': '+fmt(raw))+'</title></circle>';
      });
    }
    svg+='</svg>';
    return svg;
  }
  function chartSvg(items,label,type){return type==='radar'?radarSvg(items,label):cartesianSvg(items,label,type);}

  function pivotItems(){
    const table=root.document.getElementById('backlogTreeTable'),body=root.document.getElementById('backlogTreeBody');
    if(!table||!body)return [];
    const qtyHead=root.document.getElementById('backlogThQty'),qtyIndex=qtyHead?qtyHead.cellIndex:-1;
    if(qtyIndex<0)return [];
    return [...body.querySelectorAll('tr[data-depth="0"]')].map(row=>({
      label:row.querySelector('.backlogTreeLabel')?.textContent?.trim()||'—',
      value:parseNumber(row.cells[qtyIndex]?.textContent),
    })).filter(item=>item.label&&item.value>=0);
  }
  function updatePivotRadar(){
    if(!pivotRadarCard)return;
    const body=pivotRadarCard.querySelector('[data-pivot-radar-body]'),items=pivotItems();
    if(!body)return;
    syncRadarFilter(pivotRadarCard,'pivot',items);
    syncChartTypeSwitch(pivotRadarCard,'pivot');
    const chartType=state.pivotChartType,shown=visibleItems('pivot',items),signature=JSON.stringify({shown,hidden:state.pivotHidden,chartType});
    if(body.dataset.signature===signature)return;
    body.dataset.signature=signature;
    body.innerHTML=chartSvg(shown,L('Backlog durum grafiği','Backlog status chart'),chartType);
  }
  function schedulePivotRadar(){
    if(pivotScheduled)return;pivotScheduled=true;
    root.requestAnimationFrame(()=>{pivotScheduled=false;updatePivotRadar();});
  }

  function iconButton(action,label,glyph){
    return '<button type="button" class="blWorkspaceIconBtn" data-bl-layout="'+action+'" title="'+esc(label)+'" aria-label="'+esc(label)+'">'+glyph+'</button>';
  }
  function applyPivotLayout(){
    if(!pivotWorkspace||!pivotPanel||!pivotRadarCard)return;
    pivotPanel.classList.toggle('is-collapsed',!!state.pivotCollapsed);
    pivotRadarCard.classList.toggle('is-collapsed',!!state.pivotRadarCollapsed);
    pivotPanel.style.order=state.radarFirst?'3':'1';
    pivotRadarCard.style.order=state.radarFirst?'1':'3';
    if(splitter)splitter.style.order='2';

    const both=!state.pivotCollapsed&&!state.pivotRadarCollapsed;
    if(splitter)splitter.hidden=!both;
    if(both){
      const pivotPct=Math.round(state.pivotShare*1000)/10,radarPct=Math.round((1-state.pivotShare)*1000)/10;
      pivotWorkspace.style.gridTemplateColumns=state.radarFirst
        ? 'minmax(0,'+radarPct+'fr) 7px minmax(0,'+pivotPct+'fr)'
        : 'minmax(0,'+pivotPct+'fr) 7px minmax(0,'+radarPct+'fr)';
    }else{
      pivotWorkspace.style.gridTemplateColumns='minmax(150px,190px) minmax(0,1fr)';
      if(state.radarFirst&&state.pivotRadarCollapsed){
        pivotRadarCard.style.order='1';pivotPanel.style.order='2';
      }else if(!state.radarFirst&&state.pivotCollapsed){
        pivotPanel.style.order='1';pivotRadarCard.style.order='2';
      }
    }
    pivotPanel.querySelector('[data-bl-layout="pivot-collapse"]')?.setAttribute('aria-expanded',String(!state.pivotCollapsed));
    pivotRadarCard.querySelector('[data-bl-layout="radar-collapse"]')?.setAttribute('aria-expanded',String(!state.pivotRadarCollapsed));
  }
  function swapPivot(){state.radarFirst=!state.radarFirst;save();applyPivotLayout();}
  function bindPivotControls(){
    pivotWorkspace?.addEventListener('click',event=>{
      const typeButton=event.target.closest('[data-bl-chart-type][data-chart-kind="pivot"]');
      if(typeButton){
        const type=String(typeButton.dataset.blChartType||'');if(!CHART_TYPES.includes(type))return;
        state.pivotChartType=type;save();syncChartTypeSwitch(pivotRadarCard,'pivot');schedulePivotRadar();return;
      }
      const button=event.target.closest('[data-bl-layout]');if(!button)return;
      const action=button.dataset.blLayout;
      if(action==='pivot-collapse'){state.pivotCollapsed=!state.pivotCollapsed;save();applyPivotLayout();}
      else if(action==='radar-collapse'){state.pivotRadarCollapsed=!state.pivotRadarCollapsed;save();applyPivotLayout();}
      else if(action==='radar-filter'){const panel=pivotRadarCard?.querySelector('[data-radar-filter-panel="pivot"]');if(panel)panel.hidden=!panel.hidden;}
      else if(action==='pivot-filter-clear'){state.pivotHidden=[];save();schedulePivotRadar();}
      else if(action==='swap'){swapPivot();}
    });
    pivotWorkspace?.addEventListener('change',event=>{
      const input=event.target.closest('[data-radar-filter-kind="pivot"]');if(!input)return;
      const label=String(input.dataset.radarFilterValue||''),hidden=new Set(state.pivotHidden||[]);
      if(input.checked)hidden.delete(label);else hidden.add(label);
      state.pivotHidden=[...hidden];save();schedulePivotRadar();
    });
    splitter?.addEventListener('pointerdown',event=>{
      if(event.button!==0)return;
      event.preventDefault();splitter.setPointerCapture?.(event.pointerId);
      const onMove=move=>{
        const rect=pivotWorkspace.getBoundingClientRect();if(!rect.width)return;
        const ratio=(move.clientX-rect.left)/rect.width;
        state.pivotShare=Math.max(.28,Math.min(.72,state.radarFirst?1-ratio:ratio));
        applyPivotLayout();
      };
      const onUp=up=>{
        splitter.releasePointerCapture?.(up.pointerId);
        splitter.removeEventListener('pointermove',onMove);splitter.removeEventListener('pointerup',onUp);splitter.removeEventListener('pointercancel',onUp);
        save();
      };
      splitter.addEventListener('pointermove',onMove);splitter.addEventListener('pointerup',onUp);splitter.addEventListener('pointercancel',onUp);
    });
  }
  function ensurePivotWorkspace(){
    const table=root.document.getElementById('backlogTreeTable');if(!table)return;
    const panel=table.closest('.panel');if(!panel)return;
    if(panel.dataset.backlogWorkspaceReady==='1'){pivotPanel=panel;pivotWorkspace=panel.closest('.backlogPivotRadarWorkspace');pivotRadarCard=pivotWorkspace?.querySelector('[data-pivot-radar-card]');splitter=pivotWorkspace?.querySelector('.backlogWorkspaceSplitter');schedulePivotRadar();return;}
    pivotPanel=panel;panel.dataset.backlogWorkspaceReady='1';panel.classList.add('backlogPivotWorkspacePanel');

    pivotWorkspace=root.document.createElement('div');pivotWorkspace.className='backlogPivotRadarWorkspace';
    panel.parentNode.insertBefore(pivotWorkspace,panel);pivotWorkspace.appendChild(panel);

    const pivotHead=root.document.createElement('div');pivotHead.className='backlogWorkspaceCardHead';
    pivotHead.innerHTML='<div><strong>'+esc(L('Backlog Pivot','Backlog Pivot'))+'</strong><span>'+esc(L('Güncel durum kırılımı','Current status breakdown'))+'</span></div><div class="backlogWorkspaceCardActions">'
      +iconButton('swap',L('Radar ile yer değiştir','Swap with radar'),'⇄')
      +iconButton('pivot-collapse',L('Pivotu aç / kapat','Expand / collapse pivot'),'▾')+'</div>';
    panel.insertBefore(pivotHead,panel.firstChild);

    pivotRadarCard=root.document.createElement('div');pivotRadarCard.className='panel backlogRadarCard';pivotRadarCard.dataset.pivotRadarCard='1';
    pivotRadarCard.innerHTML='<div class="backlogWorkspaceCardHead"><div><strong>'+esc(L('Durum Grafiği','Status Chart'))+'</strong><span>'+esc(L('Yalnız ana başlıklar','Top-level groups only'))+'</span></div><div class="backlogWorkspaceCardActions">'
      +chartTypeSwitch('pivot')
      +iconButton('radar-filter',L('Grafik filtresi','Chart filter'),'⌕')
      +iconButton('swap',L('Pivot ile yer değiştir','Swap with pivot'),'⇄')
      +iconButton('radar-collapse',L('Radarı aç / kapat','Expand / collapse radar'),'▾')+'</div></div><div class="backlogRadarFilter" data-radar-filter-panel="pivot" hidden></div><div class="backlogRadarBody" data-pivot-radar-body></div>';
    pivotWorkspace.appendChild(pivotRadarCard);

    splitter=root.document.createElement('div');splitter.className='backlogWorkspaceSplitter';splitter.setAttribute('role','separator');splitter.setAttribute('aria-orientation','vertical');splitter.title=L('Sürükleyerek genişliği ayarla','Drag to resize');
    pivotWorkspace.appendChild(splitter);

    bindPivotControls();applyPivotLayout();schedulePivotRadar();
    const tbody=root.document.getElementById('backlogTreeBody');
    if(tbody)new MutationObserver(schedulePivotRadar).observe(tbody,{childList:true,subtree:true,characterData:true});
    root.addEventListener('resize',schedulePivotRadar);
  }

  function riskItems(host){
    return [...host.querySelectorAll('.bdaKpiRow .bdaKpi:not(.is-total)')].map(card=>({
      label:card.querySelector('.bdaKpiLabel')?.textContent?.trim()||'—',
      value:parseNumber(card.querySelector('.bdaKpiValue')?.textContent),
    })).filter(item=>item.label);
  }
  function ensureRiskOverview(host,kpi,card){
    let overview=host.querySelector('[data-risk-overview]');
    if(!overview){
      overview=root.document.createElement('div');overview.className='bdaRiskOverview';overview.dataset.riskOverview='1';
      kpi.parentNode.insertBefore(overview,kpi);overview.appendChild(kpi);
    }
    if(card.parentNode!==overview)overview.appendChild(card);
    overview.classList.toggle('is-radar-collapsed',!!state.riskCollapsed);
    return overview;
  }
  function renderRiskRadar(){
    const host=root.document.getElementById('backlogAnalysis');if(!host)return;
    const kpi=host.querySelector('.bdaKpiRow');if(!kpi)return;
    let card=host.querySelector('[data-risk-radar-card]');
    if(!card){
      card=root.document.createElement('div');card.className='bdaRadarCard';card.dataset.riskRadarCard='1';
      card.innerHTML='<div class="backlogWorkspaceCardHead"><div><strong>'+esc(L('Teslimat Risk Grafiği','Delivery Risk Chart'))+'</strong><span>'+esc(L('Ekrandaki risk etiketleri','Current risk labels'))+'</span></div><div class="backlogWorkspaceCardActions">'
        +chartTypeSwitch('risk')
        +iconButton('risk-filter',L('Grafik filtresi','Chart filter'),'⌕')
        +iconButton('risk-collapse',L('Radarı aç / kapat','Expand / collapse radar'),'▾')+'</div></div><div class="backlogRadarFilter" data-radar-filter-panel="risk" hidden></div><div class="backlogRadarBody" data-risk-radar-body></div>';
      card.addEventListener('click',event=>{
        const typeButton=event.target.closest('[data-bl-chart-type][data-chart-kind="risk"]');
        if(typeButton){
          const type=String(typeButton.dataset.blChartType||'');if(!CHART_TYPES.includes(type))return;
          state.riskChartType=type;save();syncChartTypeSwitch(card,'risk');renderRiskRadar();return;
        }
        const button=event.target.closest('[data-bl-layout]');if(!button)return;
        const action=button.dataset.blLayout;
        if(action==='risk-collapse'){state.riskCollapsed=!state.riskCollapsed;save();renderRiskRadar();}
        else if(action==='risk-filter'){const panel=card.querySelector('[data-radar-filter-panel="risk"]');if(panel)panel.hidden=!panel.hidden;}
        else if(action==='risk-filter-clear'){state.riskHidden=[];save();renderRiskRadar();}
      });
      card.addEventListener('change',event=>{
        const input=event.target.closest('[data-radar-filter-kind="risk"]');if(!input)return;
        const label=String(input.dataset.radarFilterValue||''),hidden=new Set(state.riskHidden||[]);
        if(input.checked)hidden.delete(label);else hidden.add(label);
        state.riskHidden=[...hidden];save();renderRiskRadar();
      });
    }
    ensureRiskOverview(host,kpi,card);
    card.classList.toggle('is-collapsed',!!state.riskCollapsed);
    card.querySelector('[data-bl-layout="risk-collapse"]')?.setAttribute('aria-expanded',String(!state.riskCollapsed));
    const body=card.querySelector('[data-risk-radar-body]'),items=riskItems(host);
    syncRadarFilter(card,'risk',items);syncChartTypeSwitch(card,'risk');
    const chartType=state.riskChartType,shown=visibleItems('risk',items),signature=JSON.stringify({shown,hidden:state.riskHidden,chartType});
    if(body&&body.dataset.signature!==signature){body.dataset.signature=signature;body.innerHTML=chartSvg(shown,L('Teslimat risk grafiği','Delivery risk chart'),chartType);}
  }
  function scheduleRiskRadar(){
    if(riskScheduled)return;riskScheduled=true;
    root.requestAnimationFrame(()=>{riskScheduled=false;renderRiskRadar();});
  }

  function init(){
    load();ensurePivotWorkspace();
    const analysis=root.document.getElementById('backlogAnalysis');
    if(analysis)new MutationObserver(scheduleRiskRadar).observe(analysis,{childList:true,subtree:true});
    scheduleRiskRadar();
  }
  if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',init,{once:true});else init();
  root.BLBacklogRadarLayout={refreshPivot:schedulePivotRadar,refreshRisk:scheduleRiskRadar,_state:state};
})(window);
